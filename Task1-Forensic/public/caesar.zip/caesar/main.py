import tkinter as tk
from tkinter import ttk

alphabet_RU = 'абвгдеёжзийклмнопрстуфхцчшщьыъэюя'
alphabet_EN = 'abcdefghijklmnopqrstuvwxyz'

def decoding(lang, step, message):
    result = ''
    if lang == 'RU':
        for i in message:
            if i in alphabet_RU:
                place = alphabet_RU.find(i)
                new_place = (place - step) % len(alphabet_RU)
                result += alphabet_RU[new_place]
            else:
                result += i
    else:
        for i in message:
            if i in alphabet_EN:
                place = alphabet_EN.find(i)
                new_place = (place - step) % len(alphabet_EN)
                result += alphabet_EN[new_place]
            else:
                result += i
    return result


window = tk.Tk()
window.title('Caesar Cipher')
window.geometry('1000x700+200+300')

bg_color = '#D6D6D6'
fg_color = '#333333'

# photo = tk.PhotoImage(file='code.png')
# window.iconphoto(False, photo)

STEP = 17

mode_var = tk.StringVar(value='encryption')  # Значение по умолчанию - шифрование
encryption_radio = ttk.Radiobutton(mode_frame, text='Шифрование', variable=mode_var, value='encryption')
encryption_radio.pack(padx=5, pady=5, anchor='w')
decryption_radio = ttk.Radiobutton(mode_frame, text='Дешифрование', variable=mode_var, value='decryption')
decryption_radio.pack(padx=5, pady=5, anchor='w')

window.mainloop()
